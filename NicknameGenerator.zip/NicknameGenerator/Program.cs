﻿using System;

namespace NicknameGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] nicknames = new string[10, 2];

            nicknames[0, 0] = "A$AP Gauge";
            nicknames[0, 1] = "A$AP Chainz";
            nicknames[1, 0] = "A$AP Cent";
            nicknames[1, 1] = "A$AP AfroMan";
            nicknames[2, 0] = "A$AP Rice";
            nicknames[2, 1] = "A$AP Frank";
            nicknames[3, 0] = "A$AP DollaBill";
            nicknames[3, 1] = "A$AP Wayne";
            nicknames[4, 0] = "A$AP Ferg";
            nicknames[4, 1] = "A$AP Mello";
            nicknames[5, 0] = "A$AP Smo";
            nicknames[5, 1] = "A$AP Scoob";
            nicknames[6, 0] = "A$AP Reese";
            nicknames[6, 1] = "A$AP Sean";
            nicknames[7, 0] = "A$AP Pokey";
            nicknames[7, 1] = "A$AP Battlecat";
            nicknames[8, 0] = "A$AP Snoop";
            nicknames[8, 1] = "A$AP Ferg";
            nicknames[9, 0] = "A$Ap Yachty";
            nicknames[9, 1] = "A$AP Dre";

            Console.WriteLine("Please enter your name: ");
            string name = Console.ReadLine();

            string[] nameparts = name.Split(new char[] {""});
        }

            public static string getNickNameComponent(string input, string[,] nicknames, string position)
            {
                string output = "";

                int index = input.Length % nicknames.GetLength(0);

                switch (position)
                {
                    case "first":
                        output = nicknames[index, 0];
                        break;
                    case "last":
                        output = nicknames[index, 1];
                        break;
                    default:
                        output = "Wrong";
                        break;

                }


                return output; ;
            }

        public static string reverser(string original)
        {

            char[] temp = original.ToCharArray();

            for (int i = 0; i < temp.Length; i++)
            {
                Console.WriteLine("{0}", temp[i]);
            }

            Array.Reverse(temp);

            Console.WriteLine(temp);

            string output = new string(temp);

            Console.WriteLine(output);

            return output;
        }
      
    }
   
}
